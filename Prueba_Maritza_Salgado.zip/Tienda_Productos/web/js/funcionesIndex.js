/* 
    Created on : 15 oct. 2022, 13:21:18
    Author     : Maritza A. Salgado
*/
function cargarElementoDinamicamente(url, elemento){
    var request = new XMLHttpRequest();
    request.open("GET", url, false);
    request.send(null);
    elemento.innerHTML = request.responseText;
}

function cargarAltaUsuario(){
    cargarElementoDinamicamente("altaUsuario.jsp", document.getElementById("contenidoDinamico"));
}

function cargarInicioSesion(){
    cargarElementoDinamicamente("inicioSesion.jsp", document.getElementById("contenidoDinamico"));
}