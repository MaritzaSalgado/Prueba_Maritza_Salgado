/* 
    Created on : 15 oct. 2022, 13:21:18
    Author     : Maritza A. Salgado
*/
function resetearFormulario() {
    document.getElementById("formularioAlta").reset();
    var btnEnviarDatos = document.getElementById("btnEnviarDatos");
    
    btnEnviarDatos.disabled = true;
}

