-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.31 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla bdtiendaproductos.tbl_categorias: ~4 rows (aproximadamente)
DELETE FROM `tbl_categorias`;
INSERT INTO `tbl_categorias` (`categoria`, `descripcion`) VALUES
	('1', 'Zapatos'),
	('2', 'Camisas'),
	('3', 'Carteras'),
	('4', 'Pantalones');

-- Volcando datos para la tabla bdtiendaproductos.tbl_productos: ~2 rows (aproximadamente)
DELETE FROM `tbl_productos`;
INSERT INTO `tbl_productos` (`codigo`, `descripcion`, `categoria`, `cantidad`, `precio`, `imagen`) VALUES
	('00', 'prueba', 'prueba', 'prueba', 'prueba', 'prueba'),
	('01', 'prueba', 'prueba', 'prueba', 'prueba', 'prueba');

-- Volcando datos para la tabla bdtiendaproductos.tbl_usuarios: ~2 rows (aproximadamente)
DELETE FROM `tbl_usuarios`;
INSERT INTO `tbl_usuarios` (`id`, `nombre`, `apellidos`, `contrasenia`, `usuario_generado_automaticamente`) VALUES
	('1', 'maritza', 'salgado', '123', 'marsal'),
	('2', 'azucena', 'garcia', '123', 'azugar');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
