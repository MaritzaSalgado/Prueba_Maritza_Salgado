/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Blob;

/**
 *
 * @author Maritza A. Salgado
 */
public class MetodosSQL {

    private Connection conexion;
    private PreparedStatement sentenciaPreparada;
    private ResultSet resultado;

    public boolean registrarUsuario(String id, String nombre, String apellidos, String contrasenia, String usuarioGeneradoAutomaticamente) {
        boolean registro = false;
        try {
            conexion = ConexionBD.conectar();
            String consulta = "INSERT INTO tbl_usuarios (id,nombre,apellidos,contrasenia,usuario_generado_automaticamente) VALUES (?,?,?,?,?)";
            sentenciaPreparada = conexion.prepareStatement(consulta);
            sentenciaPreparada.setString(1, id);
            sentenciaPreparada.setString(2, nombre);
            sentenciaPreparada.setString(3, apellidos);
            sentenciaPreparada.setString(4, contrasenia);
            sentenciaPreparada.setString(5, usuarioGeneradoAutomaticamente);

            int resultadoInsercion = sentenciaPreparada.executeUpdate();

            if (resultadoInsercion > 0) {
                registro = true; // usuario se a registrado
                System.out.println("El usuario se registro exitosamente");
            } else {
                registro = false; // usuario no se a registrado
                System.out.println("El usuario no se registro exitosamente");
            }

            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);

            }
        }
        System.out.println("Valor del registro: " + registro);
        return registro;
    }

    public boolean buscarUsuarioRepetido(String id) {
        boolean usuarioRepetido = false;
        try {
            conexion = ConexionBD.conectar();
            String consulta = "SELECT id FROM tbl_usuarios WHERE id = ?";
            sentenciaPreparada = conexion.prepareStatement(consulta);
            sentenciaPreparada.setString(1, id);
            resultado = sentenciaPreparada.executeQuery();

            if (resultado.next()) {
                usuarioRepetido = true; // usuario se a registrado BD
               // System.out.println("El usuario se registro exitosamente");
            } else {
                usuarioRepetido = false; // usuario no se a registrado BD
               // System.out.println("El usuario no se registro exitosamente");
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);

            }
        }
         System.out.println("Valor del Usuario Repetido es: " + usuarioRepetido);
        return usuarioRepetido;
    }
    
    public boolean buscarUsuarioInicioSesion(String usuario, String contrasenia) {
        boolean iniciarSesion = false;
        try {
            conexion = ConexionBD.conectar();
            String consulta = "SELECT usuario_generado_automaticamente,contrasenia FROM tbl_usuarios WHERE usuario_generado_automaticamente = ? AND contrasenia = ? ";
            sentenciaPreparada = conexion.prepareStatement(consulta);
            sentenciaPreparada.setString(1, usuario);
            sentenciaPreparada.setString(2, contrasenia);
            resultado = sentenciaPreparada.executeQuery();

            if (resultado.next()) {
                iniciarSesion = true; // usuario puede iniciar sesion ya que se a registrado BD
               // System.out.println("El usuario se registro exitosamente");
            } else {
                iniciarSesion = false; // usuario no puede iniciar sesion ya que no a registrado BD
               // System.out.println("El usuario no se registro exitosamente");
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);

            }
        }
         System.out.println("Valor del Usuario inicio de sesion es: " + iniciarSesion);
        return iniciarSesion;
    }
    
    public String buscarNombre(String usuario) {
        String nombre = null;
        try {
            conexion = ConexionBD.conectar();
            String consulta = "SELECT nombre FROM tbl_usuarios WHERE usuario_generado_automaticamente = ?";
            sentenciaPreparada = conexion.prepareStatement(consulta);
            sentenciaPreparada.setString(1, usuario);
            resultado = sentenciaPreparada.executeQuery();

            if (resultado.next()) {
                nombre = resultado.getString("nombre"); // usuario fue encontrado y obtenemos el nombre
               // System.out.println("El usuario se registro exitosamente");
            } else {
                nombre = null; // usuario no pfue encontrado y no obtenemos
               // System.out.println("El usuario no se registro exitosamente");
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);

            }
        }
         System.out.println("Valor del Usuario inicio de sesion es: " + nombre);
        return nombre;
    }
    
    
    
    public boolean registrarCategoria(String categoria, String descripcion) {
        boolean registro = false;
        try {
            conexion = ConexionBD.conectar();
            String consulta = "INSERT INTO tbl_categorias (categoria,descripcion) VALUES (?,?)";
            sentenciaPreparada = conexion.prepareStatement(consulta);
            
            sentenciaPreparada.setString(1, categoria);
            sentenciaPreparada.setString(2, descripcion);

            int resultadoInsercion = sentenciaPreparada.executeUpdate();

            if (resultadoInsercion > 0) {
                registro = true; // usuario se a registrado
                System.out.println("La categoria se registro exitosamente");
            } else {
                registro = false; // usuario no se a registrado
                System.out.println("La categoria no se registro exitosamente");
            }

            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);

            }
        }
        System.out.println("Valor del registro: " + registro);
        return registro;
    }
    
    
    
     public boolean registrarProducto(String codigo, String descripcion, String categoria, String cantidad, String precio, String imagen) {
         
        boolean registro = false;
        try {
            conexion = ConexionBD.conectar();
            String consulta = "INSERT INTO tbl_productos (codigo,descripcion,categoria,cantidad,precio,imagen) VALUES (?,?,?,?,?,?)";
            sentenciaPreparada = conexion.prepareStatement(consulta);
            
            sentenciaPreparada.setString(1, codigo);
            sentenciaPreparada.setString(2, descripcion);
            sentenciaPreparada.setString(3, categoria);
            sentenciaPreparada.setString(4, cantidad);
            sentenciaPreparada.setString (5, precio);
            sentenciaPreparada.setString(6, imagen);

            int resultadoInsercion = sentenciaPreparada.executeUpdate();

            if (resultadoInsercion > 0) {
                registro = true; // usuario se a registrado
                System.out.println("El producto se registro exitosamente");
            } else {
                registro = false; // usuario no se a registrado
                System.out.println("El producto no se registro exitosamente");
            }

            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);

            }
        }
        System.out.println("Valor del registro: " + registro);
        return registro;
    }

   
public String buscarDetalleProductos(String codigo, String descripcion, String categoria, String cantidad, String precio, String imagen) {
        String registros = null;
        try {
            conexion = ConexionBD.conectar();
            String consulta = "SELECT codigo, descripcion, categoria, cantidad, precio,imagen FROM tbl_productos";
            sentenciaPreparada = conexion.prepareStatement(consulta);
            sentenciaPreparada.setString(1, codigo);
            sentenciaPreparada.setString(2, descripcion);
            sentenciaPreparada.setString(3, categoria);
            sentenciaPreparada.setString(4, cantidad);
            sentenciaPreparada.setString (5, precio);
            sentenciaPreparada.setString(6, imagen);
            resultado = sentenciaPreparada.executeQuery();

            if (resultado.next()) {
                registros = resultado.getString("nombre"); // usuario fue encontrado y obtenemos el nombre
               // System.out.println("El usuario se registro exitosamente");
            } else {
                registros = null; // usuario no pfue encontrado y no obtenemos
               // System.out.println("El usuario no se registro exitosamente");
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);

            }
        }
         System.out.println("Valor del Usuario inicio de sesion es: " + registros);
        return registros;
    }
  
}
