
package SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
    Created on : 15 oct. 2022, 13:21:18
    Author     : Maritza A. Salgado
 */
public class ConexionBD {
    
    private static String url = "jdbc:mysql://localhost:3306/bdtiendaproductos"; //127.0.0.1 = localhost
    private static String usuario = "root";
    private static String contrasena = "admin";
    
 
    
    public static Connection conectar(){
        Connection conexion = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection(url,usuario,contrasena);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error: " + e);
        }
        
        return conexion;
    }
    
    
   
    
}
